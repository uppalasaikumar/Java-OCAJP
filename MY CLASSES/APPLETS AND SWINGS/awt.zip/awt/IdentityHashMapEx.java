import java.util.*;
class IdentityHashMapEx 
{
	public static void main(String[] args) 
	{
		HashMap m=new HashMap();
		Integer i1=new Integer(10);
		Integer i2=new Integer(10);
		m.put(i1,"Ram");
		m.put(i2,"charan")
		System.out.println(m);
	}
}
