import java.awt.*;
class Test 
{
	public static void main(String[] args) 
	{
Frame f=new Frame();
FileDialog fd=new FileDialog(f,"open",FileDialog.LOAD);

		fd.setVisible(true);
	}
}
